The Link King (Lite) is a mechanism for streamlining the processing of 
recurring linkage/unduplication tasks.  During the initial processing 
of the recurring task, the user saves the unduplication settings to a 
user-specified directory. (From the Program Set-Up screen, select "Save 
Data or Settings".)  Subsequently, using The Link King (Lite) Installation 
Program (found in the directory where The Link King was installed), the 
user identifies the files to be processed.  The Link King (Lite) Installation
Program creates a desktop shortcut for each recurring task.  The shortcut
launches The Link King (Lite) and allows completion of the linkage/unduplication
task with a couple mouse clicks.

To allow The Link King (Lite) to bypass the data importing process, the input
datasets must be formatted in a specific manner.  Data elements may need to
be renamed or recoded to meet these requirements.  The Link King (Lite) allows
the user to incorporate SAS code for renaming/recoding into a configuration
file to allow automatic formatting of the input dataset.

Setting Up The Link King (Lite) for a Specific Task

1. Create a directory to store output and configuration files for the task.
2. Use The Link King for initial processing of the task and save settings.
3. Launch The Link King (Lite) installation program and provide required info.
4. If data elements in your input dataset(s) need to be renamed/recoded, enter
   SAS code for data transformation in the ".sas" file installed in the 
   directory created in step 1 (above) by the installation program.  The prefix 
   to the ".sas" file will be the name assigned to this recurringtask by the user 
   in The Link King (Lite) installation program.  Enter the necessary SAS code in 
   the appropriately location.  DO NOT enter "data" or "step" commands.  Only enter 
   the SAS code required to rename/recode variables.  Make sure the code is 
   appropriate for the files being accessed.  Reqired data elements and associated 
   formats are detailed below:

   Required Variables               Type

   Client_Identifier                Char 
   Client_First_Name                Char
   Client_Last_Name                 Char
  
   and either

   Client_Social_Security_Number    Char
   or
   Client_Birthdate                 Num with SAS date format


   Optional Variables               Type
   Flex                             Char
   Client_Alternate_Last_Name       Char
   Client_Gender                    Char
   Client_Middle_Name               Char
   Client_Race                      Num 
			            where
   1='Caucasian' 2='African American' 3='Hispanic' 4='Asian' 
   5='Native Am' 6='Middle Eastern' 7='Other' -9='MISSING';


Executing the Recurring Task

1. Double-click the shortcut for the recurring task.
2. Verify that the appropriate files will be accessed, then click "Input Data"
3. Verify that the appropriate settings are in place, and then click "Process Data"